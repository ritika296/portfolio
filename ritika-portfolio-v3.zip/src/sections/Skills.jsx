import { useState } from 'react';
import { stackNodes } from '../data/skillNetwork';
import { skillGroups } from '../data/skills';
import Reveal from '../components/Reveal';

const RADIUS = 38; // percent

function nodePosition(index, total) {
  const angle = (2 * Math.PI * index) / total - Math.PI / 2;
  return {
    x: 50 + RADIUS * Math.cos(angle),
    y: 50 + RADIUS * Math.sin(angle),
  };
}

export default function Skills() {
  const [active, setActive] = useState(null);

  return (
    <section id="skills" className="py-24 sm:py-32">
      <div className="container-xl">
        <Reveal>
          <p className="eyebrow mb-3">Skills</p>
          <h2 className="section-heading">Ritika&rsquo;s analytics stack.</h2>
          <p className="mt-3 text-ink-500 dark:text-ink-400 max-w-xl">
            Hover a node to see how it connects to the rest of the stack.
          </p>
        </Reveal>

        <Reveal delay={100}>
          <div className="mt-14 relative w-full max-w-xl mx-auto aspect-square">
            <svg
              className="absolute inset-0 w-full h-full"
              viewBox="0 0 100 100"
              preserveAspectRatio="none"
              aria-hidden="true"
            >
              {stackNodes.map((node, i) => {
                const { x, y } = nodePosition(i, stackNodes.length);
                const isActive = active === node.name;
                return (
                  <line
                    key={node.name}
                    x1="50"
                    y1="50"
                    x2={x}
                    y2={y}
                    strokeWidth={isActive ? 0.6 : 0.3}
                    className={
                      isActive
                        ? 'stroke-teal-500'
                        : 'stroke-ink-900/10 dark:stroke-ink-100/10'
                    }
                  />
                );
              })}
            </svg>

            {/* Hub */}
            <div
              className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 card-surface ring-1 ring-teal-500/30 shadow-glow px-4 py-3 sm:px-5 sm:py-4 text-center z-10"
              style={{ maxWidth: '38%' }}
            >
              <p className="font-display font-semibold text-xs sm:text-sm text-ink-900 dark:text-ink-50 leading-tight">
                Ritika&rsquo;s
                <br />
                Analytics Stack
              </p>
            </div>

            {/* Nodes */}
            {stackNodes.map((node, i) => {
              const { x, y } = nodePosition(i, stackNodes.length);
              const isActive = active === node.name;
              return (
                <button
                  key={node.name}
                  type="button"
                  onMouseEnter={() => setActive(node.name)}
                  onFocus={() => setActive(node.name)}
                  onMouseLeave={() => setActive(null)}
                  onBlur={() => setActive(null)}
                  className={`absolute -translate-x-1/2 -translate-y-1/2 font-mono text-[10px] sm:text-xs px-2.5 py-1.5 rounded-full border whitespace-nowrap transition-all duration-200 ${
                    isActive
                      ? 'bg-teal-500 text-ink-950 border-teal-500 scale-110'
                      : 'bg-ink-50 dark:bg-ink-900 border-ink-900/15 dark:border-ink-100/15 text-ink-700 dark:text-ink-200'
                  }`}
                  style={{ left: `${x}%`, top: `${y}%` }}
                >
                  {node.name}
                </button>
              );
            })}
          </div>

          <div className="mt-6 min-h-[36px] text-center">
            {active ? (
              <div className="flex flex-wrap justify-center gap-1.5">
                {stackNodes
                  .find((n) => n.name === active)
                  .related.map((r) => (
                    <span
                      key={r}
                      className="text-[11px] font-mono px-2.5 py-1 rounded-full bg-teal-500/10 text-teal-700 dark:text-teal-300"
                    >
                      {r}
                    </span>
                  ))}
              </div>
            ) : (
              <p className="text-xs text-ink-400 dark:text-ink-500 font-mono">
                &larr; hover a node to see related tools
              </p>
            )}
          </div>
        </Reveal>

        {/* Grouped list kept for scan-ability / accessibility */}
        <Reveal delay={150}>
          <div className="mt-16 grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {skillGroups.map((group) => (
              <div key={group.category} className="card-surface p-6 h-full">
                <p className="font-display font-semibold text-ink-900 dark:text-ink-50">{group.category}</p>
                <div className="mt-4 flex flex-wrap gap-2">
                  {group.items.map((item) => (
                    <span
                      key={item}
                      className="font-mono text-[11px] px-2.5 py-1.5 rounded-full bg-teal-500/[0.08] text-teal-700 dark:text-teal-300 border border-teal-500/15"
                    >
                      {item}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </Reveal>
      </div>
    </section>
  );
}
